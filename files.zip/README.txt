StayEase - run on localhost
1. Install Node.js (v18+) and MySQL; make sure MySQL is running.
2. In this folder run:  npm install
3. Start:  npm start        (Windows PowerShell with MySQL password:  $env:DB_PASSWORD="yourpass"; npm start)
          (Mac/Linux:  DB_PASSWORD=yourpass npm start)
4. Open http://localhost:3000 in your browser.
Database, tables and sample hotels are created automatically.
