// StayEase website: Node.js + Express + MySQL (serves API and the website)
const path = require('path');
const express = require('express');
const cors = require('cors');
const mysql = require('mysql2/promise');
const bcrypt = require('bcryptjs');
const jwt = require('jsonwebtoken');

const app = express();
app.use(cors());
app.use(express.json());
app.use(express.static(path.join(__dirname, 'public'))); // the website files

const SECRET = process.env.JWT_SECRET || 'change-me';
const cfg = {
  host: process.env.DB_HOST || 'localhost',
  user: process.env.DB_USER || 'root',
  password: process.env.DB_PASSWORD || ''
};
let db;

// Creates database, tables and sample hotels automatically
async function initDb() {
  const c = await mysql.createConnection(cfg);
  await c.query('CREATE DATABASE IF NOT EXISTS stayease');
  await c.end();
  db = mysql.createPool({ ...cfg, database: 'stayease' });
  await db.query(`CREATE TABLE IF NOT EXISTS users (
    id INT AUTO_INCREMENT PRIMARY KEY, name VARCHAR(100),
    email VARCHAR(100) UNIQUE, password VARCHAR(255))`);
  await db.query(`CREATE TABLE IF NOT EXISTS hotels (
    id INT AUTO_INCREMENT PRIMARY KEY, name VARCHAR(100), city VARCHAR(60),
    price DECIMAL(10,2), rating DECIMAL(2,1))`);
  await db.query(`CREATE TABLE IF NOT EXISTS bookings (
    id INT AUTO_INCREMENT PRIMARY KEY, user_id INT, hotel_id INT,
    check_in DATE, check_out DATE, guests INT, total DECIMAL(10,2),
    status VARCHAR(20) DEFAULT 'CONFIRMED')`);
  const [[{ n }]] = await db.query('SELECT COUNT(*) AS n FROM hotels');
  if (!n) {
    await db.query('INSERT INTO hotels (name,city,price,rating) VALUES ?', [[
      ['Sea Breeze Resort', 'Goa', 6500, 4.6], ['Palm Beach Stay', 'Goa', 3800, 4.2],
      ['Royal Orchid', 'Pune', 4200, 4.4], ['Hill View Inn', 'Pune', 2200, 3.9],
      ['Marine Drive Suites', 'Mumbai', 8000, 4.7], ['City Comfort', 'Mumbai', 3000, 4.0],
      ['Heritage Palace', 'Jaipur', 5500, 4.8], ['Siddheshwar Residency', 'Solapur', 1800, 4.1]
    ]]);
  }
}

function auth(req, res, next) {
  const token = (req.headers.authorization || '').replace('Bearer ', '');
  try { req.user = jwt.verify(token, SECRET); next(); }
  catch { res.status(401).json({ error: 'Please login' }); }
}

app.post('/api/register', async (req, res) => {
  const { name, email, password } = req.body;
  if (!name || !email || !password) return res.status(400).json({ error: 'Fill all fields' });
  const hash = await bcrypt.hash(password, 10);
  try {
    await db.query('INSERT INTO users (name,email,password) VALUES (?,?,?)', [name, email, hash]);
    res.json({ message: 'Registered' });
  } catch { res.status(400).json({ error: 'Email already used' }); }
});

app.post('/api/login', async (req, res) => {
  const { email, password } = req.body;
  const [rows] = await db.query('SELECT * FROM users WHERE email=?', [email]);
  if (!rows.length || !(await bcrypt.compare(password, rows[0].password)))
    return res.status(401).json({ error: 'Wrong email or password' });
  res.json({ token: jwt.sign({ id: rows[0].id }, SECRET, { expiresIn: '7d' }), name: rows[0].name });
});

app.get('/api/hotels', async (req, res) => {
  const { city = '', maxPrice } = req.query;
  const [rows] = await db.query(
    'SELECT * FROM hotels WHERE city LIKE ? AND price <= ? ORDER BY rating DESC',
    [`%${city}%`, maxPrice || 999999]);
  res.json(rows);
});

app.post('/api/bookings', auth, async (req, res) => {
  const { hotelId, checkIn, checkOut, guests } = req.body;
  const [[hotel]] = await db.query('SELECT price FROM hotels WHERE id=?', [hotelId]);
  if (!hotel) return res.status(404).json({ error: 'Hotel not found' });
  const nights = (new Date(checkOut) - new Date(checkIn)) / 86400000;
  if (!(nights > 0)) return res.status(400).json({ error: 'Invalid dates' });
  const total = nights * hotel.price;
  const [r] = await db.query(
    'INSERT INTO bookings (user_id,hotel_id,check_in,check_out,guests,total) VALUES (?,?,?,?,?,?)',
    [req.user.id, hotelId, checkIn, checkOut, guests || 1, total]);
  res.json({ bookingId: r.insertId, total, status: 'CONFIRMED' });
});

app.get('/api/bookings', auth, async (req, res) => {
  const [rows] = await db.query(
    `SELECT b.id, b.status, b.total, b.guests, h.name AS hotel,
     DATE_FORMAT(b.check_in,'%Y-%m-%d') AS check_in,
     DATE_FORMAT(b.check_out,'%Y-%m-%d') AS check_out
     FROM bookings b JOIN hotels h ON h.id=b.hotel_id
     WHERE b.user_id=? ORDER BY b.id DESC`, [req.user.id]);
  res.json(rows);
});

app.delete('/api/bookings/:id', auth, async (req, res) => {
  await db.query("UPDATE bookings SET status='CANCELLED' WHERE id=? AND user_id=?",
    [req.params.id, req.user.id]);
  res.json({ message: 'Cancelled' });
});

initDb().then(() => app.listen(3000, () =>
  console.log('StayEase website running at http://localhost:3000')))
  .catch(e => { console.error('Database error:', e.message); process.exit(1); });
