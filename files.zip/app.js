// StayEase frontend (JavaScript)
const T = {
  en:{tagline:'Find your perfect stay',city:'City (e.g. Goa)',maxPrice:'Max price per night',search:'Search',login:'Login',register:'Register',logout:'Logout',close:'Close',name:'Your name',password:'Password',myBookings:'My Bookings',book:'Book now',night:'/ night',checkIn:'Check-in',checkOut:'Check-out',guests:'Guests',confirm:'Confirm booking',cancel:'Cancel',none:'No results',done:'Booked! Total: ₹'},
  hi:{tagline:'अपना बेहतरीन ठहराव खोजें',city:'शहर (जैसे गोवा)',maxPrice:'अधिकतम कीमत/रात',search:'खोजें',login:'लॉगिन',register:'रजिस्टर',logout:'लॉगआउट',close:'बंद करें',name:'आपका नाम',password:'पासवर्ड',myBookings:'मेरी बुकिंग',book:'अभी बुक करें',night:'/ रात',checkIn:'चेक-इन',checkOut:'चेक-आउट',guests:'मेहमान',confirm:'बुकिंग पक्की करें',cancel:'रद्द करें',none:'कोई परिणाम नहीं',done:'बुक हो गया! कुल: ₹'},
  mr:{tagline:'तुमचा परफेक्ट मुक्काम शोधा',city:'शहर (उदा. गोवा)',maxPrice:'कमाल किंमत/रात्र',search:'शोधा',login:'लॉगिन',register:'नोंदणी',logout:'लॉगआउट',close:'बंद करा',name:'तुमचे नाव',password:'पासवर्ड',myBookings:'माझे बुकिंग',book:'आता बुक करा',night:'/ रात्र',checkIn:'चेक-इन',checkOut:'चेक-आउट',guests:'पाहुणे',confirm:'बुकिंग निश्चित करा',cancel:'रद्द करा',none:'निकाल नाही',done:'बुक झाले! एकूण: ₹'},
  es:{tagline:'Encuentra tu estancia perfecta',city:'Ciudad (p. ej. Goa)',maxPrice:'Precio máx. por noche',search:'Buscar',login:'Iniciar sesión',register:'Registrarse',logout:'Salir',close:'Cerrar',name:'Tu nombre',password:'Contraseña',myBookings:'Mis reservas',book:'Reservar',night:'/ noche',checkIn:'Entrada',checkOut:'Salida',guests:'Huéspedes',confirm:'Confirmar reserva',cancel:'Cancelar',none:'Sin resultados',done:'¡Reservado! Total: ₹'},
  fr:{tagline:'Trouvez votre séjour idéal',city:'Ville (ex. Goa)',maxPrice:'Prix max par nuit',search:'Rechercher',login:'Connexion',register:"S'inscrire",logout:'Déconnexion',close:'Fermer',name:'Votre nom',password:'Mot de passe',myBookings:'Mes réservations',book:'Réserver',night:'/ nuit',checkIn:'Arrivée',checkOut:'Départ',guests:'Voyageurs',confirm:'Confirmer',cancel:'Annuler',none:'Aucun résultat',done:'Réservé ! Total : ₹'}
};
const $ = id => document.getElementById(id);
let lang = localStorage.lang || 'en', token = localStorage.token || '', hotelId = null;
const t = k => T[lang][k];

async function api(url, method = 'GET', body) {
  const r = await fetch(url, { method, headers: { 'Content-Type': 'application/json', Authorization: 'Bearer ' + token }, body: body && JSON.stringify(body) });
  const d = await r.json();
  if (!r.ok) throw new Error(d.error || 'Error');
  return d;
}

function applyLang() {
  document.querySelectorAll('[data-i18n]').forEach(e => e.textContent = t(e.dataset.i18n));
  document.querySelectorAll('[data-i18n-ph]').forEach(e => e.placeholder = t(e.dataset.i18nPh));
  $('lang').value = lang; $('authBtn').textContent = token ? t('logout') : t('login');
}

async function loadHotels() {
  const q = new URLSearchParams({ city: $('city').value, maxPrice: $('maxPrice').value });
  const list = await api('/api/hotels?' + q);
  $('hotels').innerHTML = list.length ? list.map(h => `
    <div class="card"><div class="img">🏨</div><div class="body">
      <h3>${h.name}</h3><div>📍 ${h.city} &nbsp; ⭐ ${h.rating}</div>
      <div class="price">₹${Number(h.price).toLocaleString()} ${t('night')}</div>
      <button class="primary" onclick="openBook(${h.id},'${h.name.replace(/'/g, '')}')">${t('book')}</button>
    </div></div>`).join('') : `<p>${t('none')}</p>`;
}

async function loadBookings() {
  const rows = await api('/api/bookings');
  $('bookings').innerHTML = `<h2>${t('myBookings')}</h2><table><tr><th>#</th><th>Hotel</th><th>${t('checkIn')}</th><th>${t('checkOut')}</th><th>₹</th><th></th></tr>` +
    rows.map(b => `<tr><td>${b.id}</td><td>${b.hotel}</td><td>${b.check_in}</td><td>${b.check_out}</td><td>${b.total}</td>
    <td>${b.status === 'CONFIRMED' ? `<button onclick="cancelBooking(${b.id})">${t('cancel')}</button>` : `<span class="tag">${b.status}</span>`}</td></tr>`).join('') + '</table>';
}

function show(view) { $('hotels').hidden = view !== 'hotels'; $('bookings').hidden = view !== 'bookings'; document.querySelector('.hero').hidden = view !== 'hotels'; }
function updateAuthUI() { $('bookingsBtn').hidden = !token; applyLang(); }

window.openBook = (id, name) => {
  if (!token) return $('authDlg').showModal();
  hotelId = id; $('bookTitle').textContent = name; $('bookDlg').showModal();
};
window.cancelBooking = async id => { await api('/api/bookings/' + id, 'DELETE'); loadBookings(); };

$('lang').onchange = e => { lang = localStorage.lang = e.target.value; applyLang(); loadHotels(); };
$('searchForm').onsubmit = e => { e.preventDefault(); show('hotels'); loadHotels(); };
$('authBtn').onclick = () => { if (token) { token = localStorage.token = ''; updateAuthUI(); show('hotels'); } else $('authDlg').showModal(); };
$('authClose').onclick = () => $('authDlg').close();
$('bookClose').onclick = () => $('bookDlg').close();
$('bookingsBtn').onclick = () => { show('bookings'); loadBookings(); };
$('loginBtn').onclick = async () => {
  try { const d = await api('/api/login', 'POST', { email: $('email').value, password: $('password').value });
    token = localStorage.token = d.token; $('authDlg').close(); updateAuthUI(); }
  catch (e) { alert(e.message); }
};
$('registerBtn').onclick = async () => {
  try { await api('/api/register', 'POST', { name: $('name').value, email: $('email').value, password: $('password').value });
    alert('Registered! Now click Login.'); }
  catch (e) { alert(e.message); }
};
$('confirmBtn').onclick = async () => {
  try { const d = await api('/api/bookings', 'POST', { hotelId, checkIn: $('checkIn').value, checkOut: $('checkOut').value, guests: +$('guests').value });
    $('bookDlg').close(); alert(t('done') + d.total); }
  catch (e) { alert(e.message); }
};

updateAuthUI(); loadHotels();
